`timescale 1ns/1ps
module tb;
reg clk=0,rst=1; wire [2:0] light;
traffic_light_controller dut(.clk(clk),.rst(rst),.light(light));
always #5 clk=~clk;
initial begin #15 rst=0; #200 $finish; end
initial begin $dumpfile("traffic.vcd"); $dumpvars(0,tb); end
endmodule
