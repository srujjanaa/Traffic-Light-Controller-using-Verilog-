module traffic_light_controller(input clk,input rst,output reg [2:0] light);
parameter RED=0,GREEN=1,YELLOW=2;
reg [1:0] state; reg [3:0] count;
always @(posedge clk or posedge rst) begin
 if(rst) begin state<=RED; count<=0; end
 else begin
  count<=count+1;
  case(state)
   RED: if(count==4) begin state<=GREEN; count<=0; end
   GREEN: if(count==4) begin state<=YELLOW; count<=0; end
   YELLOW: if(count==2) begin state<=RED; count<=0; end
  endcase
 end
end
always @(*) begin
 case(state)
  RED: light=3'b100;
  GREEN: light=3'b001;
  YELLOW: light=3'b010;
  default: light=3'b100;
 endcase
end
endmodule
