# Traffic Light Controller

FSM-based Verilog project.
